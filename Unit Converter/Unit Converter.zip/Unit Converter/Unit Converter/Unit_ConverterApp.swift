//
//  Unit_ConverterApp.swift
//  Unit Converter
//
//  Created by Sharvil Arjunwadkar on 23/12/20.
//

import SwiftUI

@main
struct Unit_ConverterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
