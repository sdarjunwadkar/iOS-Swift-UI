//
//  RockPaperScissorApp.swift
//  RockPaperScissor
//
//  Created by Sharvil Arjunwadkar on 25/12/20.
//

import SwiftUI

@main
struct RockPaperScissorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
