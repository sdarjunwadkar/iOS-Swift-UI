//
//  FlashzillaApp.swift
//  Flashzilla
//
//  Created by Sharvil Arjunwadkar on 27/01/21.
//

import SwiftUI

@main
struct FlashzillaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
